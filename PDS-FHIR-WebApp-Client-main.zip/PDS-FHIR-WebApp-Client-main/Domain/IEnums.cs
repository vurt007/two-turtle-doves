﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PDSFHIRWebapp
{
    public interface IEnums
    {
        public enum UpdateValue { Gender, Birthdate, Name, Contact };
    }
}
