﻿namespace PDSFHIRWebapp
{
    public interface IResponseData
    {
        public ClientResponse GetClientResponseInMemory();
        public void SetClientResponseInMemory(ClientResponse clientresponse);
    }


    public class InMemoryPatientData : IResponseData
    {
   
        ClientResponse clientresponse;
        public InMemoryPatientData()
        {
            clientresponse = new ClientResponse();

        }
        public void SetClientResponseInMemory(ClientResponse clientresponse)
        {
            this.clientresponse = clientresponse;
        }
        public ClientResponse GetClientResponseInMemory()
        {
            return clientresponse;
        }
      
    }
}

