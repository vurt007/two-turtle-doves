﻿namespace PDSFHIRWebapp
{
    public class BasicRequest
    {
        public string family { get; set; }
        public string gender { get; set; }
        public string birthdate { get; set; }
        public string postcode { get; set; }
        public string deathdate { get; set; }
        public bool fuzzysearch { get; set; }
    }
}
