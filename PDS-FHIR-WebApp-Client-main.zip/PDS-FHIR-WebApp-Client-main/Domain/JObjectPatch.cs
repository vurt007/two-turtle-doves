﻿using Hl7.Fhir.Model;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;

namespace PDSFHIRWebapp
{
    public class JObjectPatch
    {
        public string etag { get; set; }
        public string NHSNumber { get; set; }
        public Patch patch { get; set; }
        public Root root { get; set; }
        public class Patch
        {
            public string op { get; set; }
            public string path { get; set; }
            public JObject value { get; set; }
 
        }



        public class Root
        {
            public bool correction { get; set; }
            public List<Patch> patches = new List<Patch>();
        }

        public JObjectPatch()
        {
            patch = new Patch();
            root = new Root();
        }


    }
}
