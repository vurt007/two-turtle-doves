﻿using Hl7.Fhir.Model;
using System.Collections.Generic;

namespace PDSFHIRWebapp
{
    public class ClientResponse
    {
        public IEnums.UpdateValue updateValue { get; set; }
        public Patient patient { get; set; }
        public string RawJson { get; set; }
        public OperationOutcome operationoutcome { get; set; }
        public Bundle bundle { get; set; }
        public string etag { get; set; }
        public ResourceType resourcetype { get; set; }
        public string readresponsestatus { get; set; }
        public string patchresponsestatus { get; set; }
        public string contactpreferencesto { get; set; }
        public string nameid { get; set; }
        public string pollingid { get; set; }
        public string retryafter {get; set;}
        public class ResPatient
        {
            public string ResName { get; set; }
            public string ResBirthdate { get; set; }
            public string ResGender { get; set; }
            public string ResPostcode { get; set; }
            public string ResNHSNumber { get; set; }
           
        }
        public List<ResPatient> ResPatients { get; set; }
    }
}
