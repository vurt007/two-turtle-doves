using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Hl7.Fhir.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;

namespace PDSFHIRWebapp.Pages
{
    public class OperationOutcomeModel : PageModel
    {
        public string ResDiagnostics { get; set; }
        public string ResCode { get; set; }
        public string ResDisplay { get; set; }
        public string ResSystem { get; set; }
        private readonly IResponseData iresponsedata;
        private readonly IConfiguration _configuration;
        [BindProperty(SupportsGet = true)]
        public string pollid { get; set; }
        [BindProperty(SupportsGet = true)]
        public string requestissue { get; set; }
        public OperationOutcomeModel(IConfiguration configuration, IResponseData iresponsedata)
        {
            _configuration = configuration;

            this.iresponsedata = iresponsedata;
        }
        public void OnGet()
        {

            OperationOutcome opoutcome = iresponsedata.GetClientResponseInMemory().operationoutcome;
            ResDiagnostics = "Patch Status:" + iresponsedata.GetClientResponseInMemory().patchresponsestatus + " Poll Status:" + iresponsedata.GetClientResponseInMemory().readresponsestatus + " Diagnostics: " + opoutcome.Issue[0].Diagnostics;
        }
    }
}
