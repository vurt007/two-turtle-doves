using System.Net.Http;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Hl7.Fhir.Model;

namespace PDSFHIRWebapp.Pages
{
    [Authorize]
    public class UpdateBirthdateModel : PageModel
    {
        private readonly IConfiguration _configuration;
       
        private readonly IResponseData iresponsedata;
        public DateTime SessionExpires { get; set; }
        public string ResResponse { get; set; }
        public string ResName { get; set; }
        public string ResPatientID { get; set; }
        public string ResBirthdateTo { get; set; }
        public string ResBirthdateFrom { get; set; }
        public string ResUpdatedBirthdate { get; set; }
        public string ResJson { get; set; }

        [BindProperty(SupportsGet = true)]
        public DateTime BirthdateInput { get; set; }
        public string NHSNumber { get; set; }
        public string etag { get; set; }

        public UpdateBirthdateModel(IConfiguration configuration, IResponseData iresponsedata)
        {
            _configuration = configuration;
            this.iresponsedata = iresponsedata;
        }
        public async Task<IActionResult> OnGet()
        {
            ClientResponse retrievedResponse = iresponsedata.GetClientResponseInMemory();
            NHSNumber = retrievedResponse.patient.Id;
            etag = retrievedResponse.etag;

            ResPatientID = retrievedResponse.patient.Id;
            ResName = retrievedResponse.patient.Name[0].ToString();
            ResBirthdateFrom = retrievedResponse.patient.BirthDate.ToString();
                                                                        
            if (retrievedResponse.patient.BirthDate.ToString().ToLower() == BirthdateInput.Date.ToString("yyyy-MM-dd")) ResResponse = $"Sorry, your patients birthday is already {BirthdateInput}, please enter another date";
            else if(BirthdateInput.Date != DateTime.MinValue.Date)
            {
                StringPatch patchbody = CreatePatchBody();
                ClientRequest request = new ClientRequest(_configuration);
                HttpClient client = request.CreateHTTPClient();
                client = request.SetClientHeaders(client);
                ClientResponse response;
                try
                {
                    response = await request.UpdatePatientAsync(client, patchbody);
                    response.updateValue = IEnums.UpdateValue.Birthdate;
                    iresponsedata.SetClientResponseInMemory(response);
                }
                catch(Exception e)
                {
                    return RedirectToPage("./Error", new { message = e.Message });
                }
                if (response.resourcetype == ResourceType.OperationOutcome) return RedirectToPage("./OperationOutcome", new { pollid = response.pollingid, requestissue = "patch" });
                else

                    return RedirectToPage("./PollUpdate", new { polling_id = response.pollingid, patchedelement = response.updateValue, patchedvalue = ResBirthdateFrom });
            }
            return Page();


        }
        public StringPatch CreatePatchBody()
        {
            StringPatch stringpatch = new StringPatch();
            StringPatch.Patch patch = new StringPatch.Patch();
            stringpatch.etag = etag;
            stringpatch.NHSNumber = NHSNumber;
            
            patch.op = "replace";
            patch.path = "/birthDate";
            patch.value = BirthdateInput.Date.ToString("yyyy-MM-dd");
            stringpatch.root.patches.Add(patch);
            stringpatch.root.correction = true;
         
            return stringpatch;
        }
    }

}


