using System.Net.Http;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Hl7.Fhir.Serialization;
using Hl7.Fhir.Model;
using System.Collections.Generic;
using System.Linq;

namespace PDSFHIRWebapp.Pages
{
    public class RemoveContactPreferenceModel : PageModel
    {
        private readonly IConfiguration _configuration;

        private readonly IResponseData iresponsedata;
        public DateTime SessionExpires { get; set; }

        public string[] ContactMethodList = new string[]
        {"Letter", "Visit", "Telephone", "E-mail", "Minicom (Textphone)", "Telephone contact via proxy", "Sign language", "No Telephone contact" };
        public string[] WrittenCommList = new string[]
        {"Large print", "Braille", "Audio tape"};

        public Dictionary<string, string> ItemsToRemove = new Dictionary<string, string>();
        [BindProperty(SupportsGet = true)]
        public string OptionToRemove { get; set; }
        public string ResName { get; set; }
        public string ResPatientID { get; set; }
        public string ResContactMethodFrom { get; set; }
        public string ResContactMethodTo { get; set; }
        public string ResContactTimesFrom { get; set; }
        public string ResContactTimesTo { get; set; }
        public string ResContactWrittenFormatFrom { get; set; }
        public string ResContactWrittenFormatTo { get; set; }
        public string ResJson { get; set; }
        public string etag { get; set; }
        public string NHSNumber { get; set; }

        [BindProperty(SupportsGet = true)]
        public string ContactMethodInput { get; set; }
        [BindProperty(SupportsGet = true)]
        public string ContactTimeInput { get; set; }
        [BindProperty(SupportsGet = true)]
        public string WrittenCommInput { get; set; }
        int contactMethodIndex = 0, contactTimeIndex = 0, writtenCommIndex = 0;
        public bool isLastExtension;
        public Extension outerExtension { get; set; }
        public int outerExtensionIndex { get; set; }
        public RemoveContactPreferenceModel(IConfiguration configuration, IResponseData iresponsedata)
        {
            _configuration = configuration;
            this.iresponsedata = iresponsedata;
        }
        public async Task<IActionResult> OnGet()
        {
            GlobalSetup();

            if (outerExtension != null)
            {
                InitialLoad();
                ListOptionsToRemove();
                StringPatch patchbody = patchToRemove();

                if (!string.IsNullOrEmpty(OptionToRemove))
                {
                    ClientResponse response;
                    try
                    {
                        ClientRequest request = new ClientRequest(_configuration);
                        HttpClient client = request.CreateHTTPClient();
                        client = request.SetClientHeaders(client);
                        response = await request.UpdatePatientAsync(client, patchbody);
                        response.updateValue = IEnums.UpdateValue.Contact;
                        response.contactpreferencesto = "N/A";
                        iresponsedata.SetClientResponseInMemory(response);
                    }
                    catch (Exception e)
                    {
                        return RedirectToPage("./Error", new { message = e.Message });
                    }

                    if (response.resourcetype == ResourceType.OperationOutcome)
                        return RedirectToPage("./OperationOutcome");
                    else
                    {
                        string oldcontactprefs = "";
                        oldcontactprefs = ItemsToRemove.FirstOrDefault(x => x.Value == OptionToRemove).Key;
                        return RedirectToPage("./PollUpdate", new { polling_id = response.pollingid, patchedelement = response.updateValue, patchedvalue = oldcontactprefs });
                    }
                }
                return Page();
            }
            else return RedirectToPage("./AddContactPreference");
        }

        private void GlobalSetup()
        {
            ClientResponse retrievedResponse = iresponsedata.GetClientResponseInMemory();
            etag = retrievedResponse.etag;
            Patient patient = retrievedResponse.patient;
            NHSNumber = patient.Id;
            ResPatientID = patient.Id; // Display NHS number
            ResName = patient.Name[0].ToString(); // Display patient name
            outerExtension = patient.GetExtension(_configuration["NHSD:ContactPrefURL"]);
            outerExtensionIndex = patient.Extension.IndexOf(outerExtension);
        }
        private void InitialLoad()
        {
            CodeableConcept contactMethodConcept = outerExtension.GetExtensionValue<CodeableConcept>("PreferredContactMethod");
            CodeableConcept writtenContactConcept = outerExtension.GetExtensionValue<CodeableConcept>("PreferredWrittenCommunicationFormat");
            FhirString preferredContactTimes = outerExtension.GetExtensionValue<FhirString>("PreferredContactTimes");
            if (contactMethodConcept != null) ResContactMethodFrom = contactMethodConcept.Coding[0].Display;
            if (writtenContactConcept != null) ResContactWrittenFormatFrom = writtenContactConcept.Coding[0].Display;
            if (preferredContactTimes != null) ResContactTimesFrom = preferredContactTimes.ToString();
        }

        private void ListOptionsToRemove()
        {
            ItemsToRemove.Add("All contact preferences", _configuration["NHSD:ContactPrefURL"]);
            if (outerExtension.GetExtensionValue<CodeableConcept>("PreferredContactMethod") != null)
                ItemsToRemove.Add($"Contact Method: {outerExtension.GetExtensionValue<CodeableConcept>("PreferredContactMethod").Coding[0].Display}", "PreferredContactMethod");
            if (outerExtension.GetExtensionValue<CodeableConcept>("PreferredWrittenCommunicationFormat") != null)
                ItemsToRemove.Add($"Written Communication Format: {outerExtension.GetExtensionValue<CodeableConcept>("PreferredWrittenCommunicationFormat").Coding[0].Display}", "PreferredWrittenCommunicationFormat");
            if (outerExtension.GetExtensionValue<FhirString>("PreferredContactTimes") != null)
                ItemsToRemove.Add($"Contact Time: {outerExtension.GetExtensionValue<FhirString>("PreferredContactTimes").ToString()}", "PreferredContactTimes");
        }

        private StringPatch patchToRemove()
        {
            StringPatch patchbody = new StringPatch();
            if (outerExtension.Extension.Count <= 1)
            {
                isLastExtension = true;
            }
            if (OptionToRemove == _configuration["NHSD:ContactPrefURL"])
            {
                isLastExtension = true;
                patchbody = CreatePatchBody(_configuration["NHSD:ContactPrefURL"], outerExtensionIndex, 0);
            }
            if (OptionToRemove == "PreferredContactMethod")
            {
                contactMethodIndex = UpdatePreferredContactMethodPatch();
                patchbody = CreatePatchBody("PreferredContactMethod", outerExtensionIndex, contactMethodIndex);
            }
            else if (OptionToRemove == "PreferredWrittenCommunicationFormat")
            {
                writtenCommIndex = UpdatePreferredWrittenCommunicationFormatPatch();
                patchbody = CreatePatchBody("PreferredWrittenCommunicationFormat", outerExtensionIndex, writtenCommIndex);
            }
            else
            {
                contactTimeIndex = UpdatePreferredContactTimesPatch();
                patchbody = CreatePatchBody("PreferredContactTimes", outerExtensionIndex, contactTimeIndex);
            }
            return patchbody;
        }

        public int UpdatePreferredContactMethodPatch()
        {
            Extension contactMethodExtension = outerExtension.GetExtension("PreferredContactMethod");
            int contactMethodIndex = outerExtension.Extension.IndexOf(contactMethodExtension);
            return contactMethodIndex;
        }
        public int UpdatePreferredWrittenCommunicationFormatPatch()
        {

            Extension writtenCommExtension = outerExtension.GetExtension("PreferredWrittenCommunicationFormat");
            int writtenCommIndex = outerExtension.Extension.IndexOf(writtenCommExtension);
            return writtenCommIndex;
        }
        public int UpdatePreferredContactTimesPatch()
        {
            Extension contactTimeExtension = outerExtension.GetExtension("PreferredContactTimes");
            contactTimeIndex = outerExtension.Extension.IndexOf(contactTimeExtension);
            FhirString value = new FhirString(ContactTimeInput);
            return contactTimeIndex;
        }

        public StringPatch CreatePatchBody(string url, int outerExtensionIndex, int innerExtensionIndex)
        {
            StringPatch stringpatch = new StringPatch();
            stringpatch.etag = etag;
            stringpatch.NHSNumber = NHSNumber;

            StringPatch.Patch testpatch = new StringPatch.Patch();
            testpatch.op = "test";
            testpatch.path = $"/extension/{outerExtensionIndex}/extension/{innerExtensionIndex}/url";
            testpatch.value = url;

            StringPatch.Patch removepatch = new StringPatch.Patch();
            removepatch.op = "remove";
            removepatch.path = $"/extension/{outerExtensionIndex}/extension/{innerExtensionIndex}";
            removepatch.value = "";

            if (isLastExtension)
            {
                testpatch.path = $"/extension/{outerExtensionIndex}/url";
                testpatch.value = _configuration["NHSD:ContactPrefURL"];
                removepatch.path = $"/extension/{outerExtensionIndex}";
            }    
            stringpatch.root.patches.Add(testpatch);
            stringpatch.root.patches.Add(removepatch);
            stringpatch.root.correction = false;
            return stringpatch;
        }
    }
}

