using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace PDSFHIRWebapp.Pages
{
    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public class ErrorModel : PageModel
    {
        public string RequestId { get; set; }
        public string statuscode { get; set; }
        public string XRequestId { get; set; }
        public string CorrelationID { get; set; }
        public string ResError { get; set; }
        private readonly IConfiguration _configuration;

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);

        private readonly ILogger<ErrorModel> _logger;

        public ErrorModel(ILogger<ErrorModel> logger, IConfiguration configuration)
        {
            _logger = logger;
            _configuration = configuration;
        }

        public void OnGet(string message)
        {
            ResError = message;
            RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier;
            XRequestId = _configuration["NHSD:X-Request-ID"];
            CorrelationID = _configuration["NHSD:X-Correlation-ID"];
            statuscode = _configuration["NHSD:statuscode"];
        }
    }
}
