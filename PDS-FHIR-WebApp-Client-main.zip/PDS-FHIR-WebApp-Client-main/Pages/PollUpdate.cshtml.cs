using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Hl7.Fhir.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;

namespace PDSFHIRWebapp.Pages
{
    public class PollUpdateModel : PageModel
    {
        private readonly IConfiguration _configuration;
       
        private readonly IResponseData iresponsedata;
        public string ResNHSNumber { get; set; }

        [BindProperty(SupportsGet = true)]
        public string NHSNumberIp { get; set; }
        public string ResName { get; set; }
        public string ResDataFrom { get; set; }
        public string ResDataTo { get; set; }
        public string ResLabelFrom { get; set; }
        public string ResLabelTo { get; set; }
        public string ResResponse { get; set; }
        public string ResPatchdata {get; set;}

        public string ResHeaderText { get; set; }
      
        public string ResJson { get; set; }

        public PollUpdateModel(IConfiguration configuration, IResponseData iresponsedata)
        {
            _configuration = configuration;
      
            this.iresponsedata = iresponsedata;
        }
        public async Task<IActionResult> OnGetAsync(string polling_id, IEnums.UpdateValue patchedelement, string patchedvalue)
        {
            ResPatchdata = patchedelement.ToString();

            
            if (NHSNumberIp == null && polling_id != null)
            {
                ClientResponse response;
                ClientRequest request = new ClientRequest(_configuration);
                HttpClient client = request.CreateHTTPClient();
                request.SetClientHeaders(client);

                try
                {
                    if (polling_id != null)
                    {
                        response = await request.pollPatient(polling_id, iresponsedata.GetClientResponseInMemory().retryafter, client);
                    
                    }
                    else
                    {
                        throw new Exception("Content Location Empty - No polling ID found.");
                    }
                }
                catch(Exception e)
                {
                    return RedirectToPage("./Error", new { message = e.Message });
                }

                ClientResponse patchedresponse = iresponsedata.GetClientResponseInMemory();
                iresponsedata.SetClientResponseInMemory(response);
                if (response.resourcetype == ResourceType.OperationOutcome) return RedirectToPage("./OperationOutcome", new { pollid = patchedresponse.pollingid, requestissue = "polling" });

                if (response.patient != null)
                {
                    ResNHSNumber = response.patient.Id;
                    ResName = response.patient.Name[0].ToString();

                }
                ResResponse ="Patch Response: " + patchedresponse.patchresponsestatus +" + Poll Response: " + response.readresponsestatus;


                switch (patchedelement)
                {
                    case IEnums.UpdateValue.Gender:
                        ResDataFrom = patchedvalue;
                        ResDataTo = response.patient.Gender.ToString();
                        ResLabelFrom = "Gender has been changed from:";
                        ResLabelTo = "Gender is now:";
                        break;
                    case IEnums.UpdateValue.Name:
                        ResDataFrom = patchedvalue;
                        ResDataTo = response.patient.Name[0].ToString();
                        ResLabelFrom = "Name has been changed from:";
                        ResLabelTo = "Name is now:";
                        break;
                    case IEnums.UpdateValue.Birthdate:
                        ResDataFrom = patchedvalue;
                        ResDataTo = response.patient.BirthDate.ToString();
                        ResLabelFrom = "Birthdate has been changed from:";
                        ResLabelTo = "Birthdate is now:";
                        break;
                   
                    case IEnums.UpdateValue.Contact:
                        ResDataFrom = patchedvalue;
                        ResDataTo = patchedresponse.contactpreferencesto;
                        ResLabelFrom = "Contact preference has been changed from:";
                        ResLabelTo = "Contact preference is now:";
                        break;
                    default:

                        break;
                }
                ResHeaderText = patchedelement.ToString();
                ResJson = response.RawJson;
                return Page();
            }
            else
            {
                return RedirectToPage("./RetrievePatientID", new { NHSNumberInput = NHSNumberIp });
            }
          
        }
    }
}
