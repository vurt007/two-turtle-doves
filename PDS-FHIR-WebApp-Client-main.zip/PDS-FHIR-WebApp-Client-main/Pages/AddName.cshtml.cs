using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using Hl7.Fhir.Model;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace PDSFHIRWebapp.Pages
{
    [Authorize]
    public class AddNameModel : PageModel
    {
        private readonly IConfiguration _configuration;

        private readonly IResponseData iresponsedata;
        public DateTime SessionExpires { get; set; }

        public List<string> Names = new List<string>();

        public string ResUpdatedName { get; set; }
        public string ResResponse { get; set; }
        public string ResPatientID { get; set; }
        public string ResNameTo { get; set; }
        public string ResNameFrom { get; set; }
        public string ResJson { get; set; }

        [BindProperty(SupportsGet = true)]
        public string NewName { get; set; }
        [BindProperty(SupportsGet = true)]
        public int NameSelector { get; set; }
        public string NHSNumber { get; set; }
        public string etag { get; set; }

        public AddNameModel(IConfiguration configuration, IResponseData iresponsedata)
        {
            _configuration = configuration;

            this.iresponsedata = iresponsedata;
        }
        public async Task<IActionResult> OnGet()
        {

            ClientResponse retrievedResponse = iresponsedata.GetClientResponseInMemory();
            ResPatientID = retrievedResponse.patient.Id;
            NHSNumber = retrievedResponse.patient.Id;
            etag = retrievedResponse.etag;
            ResNameFrom = retrievedResponse.patient.Name[0].ToString();
            NameUpdateOptions(retrievedResponse.patient);


            if (!string.IsNullOrEmpty(NewName))
            {
                StringPatch patchbody = NameElementToChange(NameSelector, retrievedResponse);


                ClientRequest request = new ClientRequest(_configuration);
                HttpClient client = request.CreateHTTPClient();
                client = request.SetClientHeaders(client);
                ClientResponse response;
                try
                {
                    response = await request.UpdatePatientAsync(client, patchbody);
                    response.updateValue = IEnums.UpdateValue.Name;
                    iresponsedata.SetClientResponseInMemory(response);
                }
                catch (Exception e)
                {
                    return RedirectToPage("./Error", new { message = e.Message });
                }

                if (response.resourcetype == ResourceType.OperationOutcome) return RedirectToPage("./OperationOutcome", new { pollid = response.pollingid, requestissue = "patch" });
                else
                  
                    return RedirectToPage("./PollUpdate", new { polling_id = response.pollingid, patchedelement = response.updateValue, patchedvalue = ResNameFrom });


            }
            return Page();
        }
        public StringPatch CreatePatchBody(string id, string path)
        {
            StringPatch stringpatch = new StringPatch();
            stringpatch.etag = etag;
            stringpatch.NHSNumber = NHSNumber;
            StringPatch.Patch idpatch = new StringPatch.Patch();
            idpatch.op = "add";
            idpatch.path = "/name/0/id";
            idpatch.value = id;
            StringPatch.Patch namepatch = new StringPatch.Patch();
            namepatch.op = "add";
            namepatch.path = path;
            namepatch.value = NewName;

            stringpatch.root.patches.Add(namepatch);
            stringpatch.root.patches.Add(idpatch);

            return stringpatch;
        }

        private void NameUpdateOptions(Patient updatepatient)
        {
            Names.Add($"Before {updatepatient.Name[0].GivenElement[0]}");

            for (int i = 0; i < updatepatient.Name[0].GivenElement.Count - 1; i++)
            {
                Names.Add($"{updatepatient.Name[0].GivenElement[i]}< x <{updatepatient.Name[0].GivenElement[i + 1]}");
            }
            Names.Add($"After {updatepatient.Name[0].GivenElement[updatepatient.Name[0].GivenElement.Count - 1]}");

        }

        public StringPatch NameElementToChange(int FromNameInput, ClientResponse updateresponse)
        {
            return  CreatePatchBody(updateresponse.patient.Name[0].ElementId, $"/name/0/given/{FromNameInput}");
        }
    }

}


