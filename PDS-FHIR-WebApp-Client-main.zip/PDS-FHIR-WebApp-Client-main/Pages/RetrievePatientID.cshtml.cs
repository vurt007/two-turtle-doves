using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using Hl7.Fhir.Rest;
using Hl7.Fhir.Model;
using Microsoft.AspNetCore.Mvc;
using Hl7.Fhir.Serialization;
using static PDSFHIRWebapp.ClientResponse;
using System.Text.RegularExpressions;

namespace PDSFHIRWebapp.Pages
{
    [Authorize]
    public class RetrievePatientID : PageModel
    {
        private readonly IConfiguration _configuration;
        
        private readonly IResponseData iresponsedata;
        public DateTime SessionExpires { get; set; }

        public string ResResponse { get; set; }
        public string ResMessage { get; set; }
        public string ResJson { get; set; }
        public ResPatient respatient = new ResPatient();
        public bool showbuttons { get; set; }

        [BindProperty(SupportsGet = true)]
        public string NHSNumberInput { get; set; }

        public RetrievePatientID(IConfiguration configuration, IResponseData iresponsedata)
        {
            _configuration = configuration;
          
            this.iresponsedata = iresponsedata;
            showbuttons = false;
        }
        public IActionResult OnGet(string NHSNumberInput)
        {
            if (!string.IsNullOrEmpty(NHSNumberInput))
            {
                if (Regex.Match(NHSNumberInput, "^[0-9]{10,10}$").Success)
                {
                    // first name was incorrect  



                   
                        ClientRequest request = new ClientRequest(_configuration);
                        FhirClient client = request.CreateFHIRClient();
                        client = request.SetClientHeaders(client);
                        ClientResponse response;
                        try
                        {
                            response = request.FindNHSNumber(NHSNumberInput, client);
                        }
                        catch (Exception e)
                        {
                            return RedirectToPage("./Error", new { message = e.Message });
                        }
                        iresponsedata.SetClientResponseInMemory(response);
                        var serializer = new FhirJsonSerializer(new SerializerSettings() { Pretty = true });
                        string rawjson = serializer.SerializeToString(response.patient);
                        ResResponse = response.readresponsestatus;
                        FillFields(response.patient, rawjson);
                        showbuttons = true;
                    
                }
               else
                {
                    ResMessage = "Please input a real NHS number";
                }
            }
            return Page();
        }

        public void FillFields(Patient patientrecord, string rawjson)
        {
            PatientResult presult = new PatientResult();
            respatient = presult.SetResults(patientrecord);
            var tokenExpiresAt = _configuration["OAUTH:tokenExpiresAt"];
            ResJson = rawjson;
            SessionExpires = Convert.ToDateTime(tokenExpiresAt);
        }
    }
}
