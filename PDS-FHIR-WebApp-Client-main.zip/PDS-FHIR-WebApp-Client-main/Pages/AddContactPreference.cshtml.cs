using System.Net.Http;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Hl7.Fhir.Serialization;
using Hl7.Fhir.Model;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;

namespace PDSFHIRWebapp.Pages
{
    public class AddContactPreferenceModel : PageModel
    {
        private readonly IConfiguration _configuration;

        private readonly IResponseData iresponsedata;
        public DateTime SessionExpires { get; set; }
        public Dictionary<string, int> ContactMethods = new Dictionary<string, int>() {
            {"Letter", 1 },
            {"Visit", 2 },
            {"Telephone", 3 },
            {"E-mail", 4 },
            {"Minicom (Textphone)", 5 },
            {"Telephone contact via proxy", 6 },
            {"Sign language", 7 },
            {"No Telephone contact", 8 }
        };

        public Dictionary<string, int> WrittenCommFormats = new Dictionary<string, int>() {
            {"Large print", 11 },
            {"Braille", 12 },
            {"Audio tape", 13 }
        };

        public List<string> ExistingContactPrefs = new List<string>();

        public string ResName { get; set; }
        public string ResPatientID { get; set; }
        public string ResExistingContactMethod { get; set; }
        public string ResExistingWrittenFormat { get; set; }
        public string ResExistingContactTime { get; set; }
        public string ResContactMethodTo { get; set; }
        public string ResJson { get; set; }
        public bool contactMethodExists { get; set; }
        public bool writtenCommsExists { get; set; }
        public bool contactTimesExists { get; set; }


        [BindProperty(SupportsGet = true)]
        public string ContactMethodInput { get; set; }
        [BindProperty(SupportsGet = true)]
        public string ContactTimeInput { get; set; }
        [BindProperty(SupportsGet = true)]
        public string WrittenCommInput { get; set; }
        public Extension existingOuterExtension {get; set; }
        int outerExtensionIndex = 0;
        string etag = "", NHSNumber = "", newcontactprefs = "";

        public AddContactPreferenceModel(IConfiguration configuration, IResponseData iresponsedata)
        {
            _configuration = configuration;
            this.iresponsedata = iresponsedata;
            contactTimesExists = false;
            contactMethodExists = false;
            writtenCommsExists = false;
        }
        public async Task<IActionResult> OnGet()
        {
            GlobalSetup();

            if (existingOuterExtension != null)
            {
                if (InitialLoad(existingOuterExtension))
                    return RedirectToPage("./UpdateContact");
            }

            Extension newOuterExtension = createExtensions();
            if (newOuterExtension.Extension.Count > 0)
            {
                JObjectPatch patchbody = patchToAdd(newOuterExtension);    
                ClientRequest request = new ClientRequest(_configuration);
                HttpClient client = request.CreateHTTPClient();
                client = request.SetClientHeaders(client);
                ClientResponse response;
                try
                {
                    response = await request.UpdatePatientAsync(client, patchbody);
                    response.updateValue = IEnums.UpdateValue.Contact;
                    response.contactpreferencesto = newcontactprefs;
                    iresponsedata.SetClientResponseInMemory(response);
                }
                catch (Exception e)
                {
                    return RedirectToPage("./Error", new { message = e.Message });
                }

                if (response.resourcetype == ResourceType.OperationOutcome) return RedirectToPage("./OperationOutcome");
                else
                    return RedirectToPage("./PollUpdate", new { polling_id = response.pollingid, patchedelement = response.updateValue, patchedvalue = "N/A" });
            }


            return Page();
        }

        private void GlobalSetup()
        {
            ClientResponse retrievedResponse = iresponsedata.GetClientResponseInMemory();
            etag = retrievedResponse.etag;
            Patient patient = retrievedResponse.patient;
            NHSNumber = patient.Id;
            ResPatientID = patient.Id;
            ResName = patient.Name[0].ToString();
    
            existingOuterExtension = patient.GetExtension(_configuration["NHSD:ContactPrefURL"]);
            outerExtensionIndex = patient.Extension.IndexOf(existingOuterExtension);

        }

        public bool InitialLoad(Extension outerExtension)
        {
            CodeableConcept contactMethodConcept = outerExtension.GetExtensionValue<CodeableConcept>("PreferredContactMethod");
            CodeableConcept writtenContactConcept = outerExtension.GetExtensionValue<CodeableConcept>("PreferredWrittenCommunicationFormat");
            FhirString preferredContactTimes = outerExtension.GetExtensionValue<FhirString>("PreferredContactTimes");
            if (contactMethodConcept != null)
            {
                ExistingContactPrefs.Add(contactMethodConcept.Coding[0].Display);
                contactMethodExists = true;
            }
            if (writtenContactConcept != null)
            {
                writtenCommsExists = true;
                ExistingContactPrefs.Add(writtenContactConcept.Coding[0].Display);
            }
            if (preferredContactTimes != null)
            {
                contactTimesExists = true;
                ExistingContactPrefs.Add(preferredContactTimes.ToString());
            }

            if (contactTimesExists && writtenCommsExists && contactMethodExists)
                return true;
            else return false;

        }

        public Extension createExtensions()
        {
            Extension newOuterExtension = new Extension();
            if (!string.IsNullOrEmpty(ContactMethodInput))
            {
                CodeableConcept concept = CreateConcept(ContactMethodInput, "https://fhir.nhs.uk/R4/CodeSystem/UKCore-PreferredContactMethod", ContactMethods);
                newOuterExtension.AddExtension("PreferredContactMethod", concept);

                newcontactprefs = ContactMethodInput + ", ";
            }
            if (!string.IsNullOrEmpty(WrittenCommInput))
            {
                CodeableConcept concept = CreateConcept(WrittenCommInput, "https://fhir.nhs.uk/R4/CodeSystem/UKCore-PreferredWrittenCommunicationFormat", WrittenCommFormats);
                newOuterExtension.AddExtension("PreferredWrittenCommunicationFormat", concept);
                newcontactprefs += WrittenCommInput + ", ";

            }
            if (!string.IsNullOrEmpty(ContactTimeInput))
            {
                FhirString contacttime = new FhirString();
                contacttime.Value = ContactTimeInput;
                newOuterExtension.AddExtension("PreferredContactTimes", contacttime);
                newcontactprefs += ContactTimeInput;

            }
            newOuterExtension.Url = _configuration["NHSD:ContactPrefURL"];
            return newOuterExtension;
        }
        public CodeableConcept CreateConcept(string input, string system, Dictionary<string, int> list)
        {
            Coding coding = new Coding();
            coding.Code = list[input].ToString();
            coding.Display = input;
            coding.System = system;
            CodeableConcept concept = new CodeableConcept();
            concept.Coding.Add(coding);
            return concept;
        }

        public JObjectPatch patchToAdd(Extension newOuterExtension)
        {
            JObjectPatch patchbody = new JObjectPatch();
            if (existingOuterExtension == null)
            {
                patchbody.root.patches.Add(CreatePatchBody(newOuterExtension.ToJObject(), "/extension/-"));
            }
            else
            {
                foreach (Extension ext in newOuterExtension.Extension)
                {
                    patchbody.root.patches.Add(CreatePatchBody(ext.ToJObject(), $"/extension/{outerExtensionIndex}/extension/-"));
                }
            }
            patchbody.root.correction = false;
            patchbody.etag = etag;
            patchbody.NHSNumber = NHSNumber;

            return patchbody;
        }

        public JObjectPatch.Patch CreatePatchBody(JObject exts, string path)
        {
            var patchroot = new JObjectPatch.Root();


            JObjectPatch.Patch patch = new JObjectPatch.Patch();
            patch.op = "add";
            patch.path = path;
            patch.value = exts;
            return patch;
        }




    }
}

