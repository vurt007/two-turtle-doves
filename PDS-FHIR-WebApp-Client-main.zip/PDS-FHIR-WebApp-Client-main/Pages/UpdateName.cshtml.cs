using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using Hl7.Fhir.Model;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace PDSFHIRWebapp.Pages
{
    [Authorize]
    public class UpdateNameModel : PageModel
    {

        private readonly IConfiguration _configuration;

        private readonly IResponseData iresponsedata;
        public DateTime SessionExpires { get; set; }
        public StringPatch patchbody { get; set; }
        public string temppatchresponsestatus = "";
        public List<string> Names = new List<string>();
        public string ResResponse { get; set; }
        public string ResUpdatedName { get; set; }
        public string ResPatientID { get; set; }
        public string ResNameTo { get; set; }
        public string ResNameFrom { get; set; }
        public string ResJson { get; set; }

        [BindProperty(SupportsGet = true)]
        public string NewName { get; set; }
        [BindProperty(SupportsGet = true)]
        public int NameSelector { get; set; }
        public string NHSNumber { get; set; }
        public string etag { get; set; }


        public UpdateNameModel(IConfiguration configuration, IResponseData iresponsedata)
        {
            _configuration = configuration;

            this.iresponsedata = iresponsedata;
        }
        public async Task<IActionResult> OnGet()
        {

            ClientResponse retrievedResponse = iresponsedata.GetClientResponseInMemory();
            etag = retrievedResponse.etag;
            NHSNumber = retrievedResponse.patient.Id;
            NameUpdateOptions(retrievedResponse.patient);

            ResPatientID = retrievedResponse.patient.Id;
            ResNameFrom = retrievedResponse.patient.Name[0].ToString();

            if (!string.IsNullOrEmpty(NewName))
            {

                StringPatch patchbody = NameElementToChange(NameSelector, retrievedResponse);
                ClientRequest request = new ClientRequest(_configuration);
                HttpClient client = request.CreateHTTPClient();
                client = request.SetClientHeaders(client);
                ClientResponse response;
                try
                {
                    response = await request.UpdatePatientAsync(client, patchbody);
                    response.updateValue = IEnums.UpdateValue.Name;
                    iresponsedata.SetClientResponseInMemory(response);
                }
                catch (Exception e)
                {
                    return RedirectToPage("./Error", new { message = e.Message });
                }
                if (response.resourcetype == ResourceType.OperationOutcome) return RedirectToPage("./OperationOutcome", new { pollid = response.pollingid, requestissue = "patch" });
                else

                    return RedirectToPage("./PollUpdate", new { polling_id = response.pollingid, patchedelement = response.updateValue, patchedvalue = ResNameFrom });


              
            }
            else return Page();
        }
        private void NameUpdateOptions(Patient updatepatient)
        {
            Names.Add(updatepatient.Name[0].FamilyElement.ToString()); //Family name as 0 in list element.
            foreach (var given in updatepatient.Name[0].GivenElement)
            {
                Names.Add(given.ToString());
            }
        }

        public StringPatch NameElementToChange(int FromNameInput, ClientResponse updateresponse)
        {
            if (FromNameInput == 0)
            {
                NewName = NewName.ToUpper();
                return CreatePatchBody(updateresponse.patient.Name[0].ElementId, "/name/0/family");
            }
            else
            {
                NewName = char.ToUpper(NewName[0]) + NewName.Substring(1);
                return CreatePatchBody(updateresponse.patient.Name[0].ElementId, $"/name/0/given/{FromNameInput - 1}");
            }
        }

        public StringPatch CreatePatchBody(string id, string path)
        {
            StringPatch stringpatch = new StringPatch();
            stringpatch.NHSNumber = NHSNumber;
            stringpatch.etag = etag;

            StringPatch.Patch idpatch = new StringPatch.Patch();
            idpatch.op = "replace";
            idpatch.path = "/name/0/id";
            idpatch.value = id;
            StringPatch.Patch namepatch = new StringPatch.Patch();
            namepatch.op = "replace";
            namepatch.path = path;
            namepatch.value = NewName;
            stringpatch.root.patches.Add(namepatch);
            stringpatch.root.patches.Add(idpatch);

            return stringpatch;
        }

    }

}


