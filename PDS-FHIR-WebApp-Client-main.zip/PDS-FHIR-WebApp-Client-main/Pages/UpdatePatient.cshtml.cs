using System.Net.Http;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using Hl7.Fhir.Model;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PDSFHIRWebapp.Pages
{
    [Authorize]
    public class UpdatePatientModel : PageModel
    {
        private readonly IConfiguration _configuration;

        private readonly IResponseData iresponsedata;
        public DateTime SessionExpires { get; set; }
        public List<string> Genders = new List<string>();
        public string ResResponse { get; set; }
        public string ResName { get; set; }
        public string ResPatientID { get; set; }
        public string ResGenderTo { get; set; }
        public string ResGenderFrom { get; set; }
        public string ResUpdatedGender { get; set; }
        public string ResJson { get; set; }
        [BindProperty(SupportsGet = true)]
        public string GenderInput { get; set; }
        public string etag { get; set; }
        public string NHSNumber { get; set; }
    

        public UpdatePatientModel(IConfiguration configuration, IResponseData iresponsedata)
        {
            _configuration = configuration;

            this.iresponsedata = iresponsedata;
        }
        public async Task<IActionResult> OnGet()
        {
          

            ClientResponse updateresponse = iresponsedata.GetClientResponseInMemory();
            etag = updateresponse.etag;
            NHSNumber = updateresponse.patient.Id;

            GenderUpdateOptions(updateresponse.patient.Gender);

            ResPatientID = updateresponse.patient.Id;
            ResName = updateresponse.patient.Name[0].ToString();
            ResGenderFrom = updateresponse.patient.Gender.ToString();

            if (!string.IsNullOrEmpty(GenderInput))
            {
                // Test with fetch and update at once
                //ClientRequest temprequest = new ClientRequest(_configuration);
                //FhirClient tempclient = temprequest.CreateFHIRClient();
                //tempclient = temprequest.SetClientHeaders(tempclient);
                //ClientResponse tempresponse;
               

                StringPatch patchbody = CreatePatchBody();
                ClientRequest request = new ClientRequest(_configuration);
                HttpClient client = request.CreateHTTPClient();
                client = request.SetClientHeaders(client);
                ClientResponse response;
               
                try
                {
                    
                    //tempresponse = temprequest.FindNHSNumber(iresponsedata.GetClientResponseInMemory().patient.Id, tempclient);
                    response = await request.UpdatePatientAsync(client, patchbody);
                    response.updateValue = IEnums.UpdateValue.Gender;
                    iresponsedata.SetClientResponseInMemory(response);
                }
                catch (Exception e)
                {
                    return RedirectToPage("./Error", new { message = e.Message });
                }




                if (response.resourcetype == ResourceType.OperationOutcome) return RedirectToPage("./OperationOutcome", new { pollid = response.pollingid, requestissue = "patch" });
                else
                    return RedirectToPage("./PollUpdate", new { polling_id = response.pollingid, patchedelement = response.updateValue, patchedvalue = ResGenderFrom });
            }
            else return Page();

        }
        public StringPatch CreatePatchBody()
        {
            StringPatch stringpatch = new StringPatch();
            StringPatch.Patch patch = new StringPatch.Patch();
            stringpatch.etag = etag;
            stringpatch.NHSNumber = NHSNumber;
            patch.op = "replace";
            patch.path = "/gender";
            patch.value = GenderInput.ToLower();
            stringpatch.root.patches.Add(patch);
            stringpatch.root.correction = true;
    
            return stringpatch;
        }

        private void GenderUpdateOptions(AdministrativeGender? Gender)
        {
            if (Gender != AdministrativeGender.Male) Genders.Add(AdministrativeGender.Male.ToString());
            if (Gender != AdministrativeGender.Female) Genders.Add(AdministrativeGender.Female.ToString());
            if (Gender != AdministrativeGender.Unknown) Genders.Add(AdministrativeGender.Unknown.ToString());
        }
    }

}


