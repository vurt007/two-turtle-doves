using System;
using System.Collections.Generic;
using Hl7.Fhir.Model;
using Hl7.Fhir.Rest;
using Hl7.Fhir.Serialization;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using static PDSFHIRWebapp.ClientResponse;

namespace PDSFHIRWebapp.Pages
{
    [Authorize]
    public class BasicSearchPostcodeModel : PageModel
    {
        
        private readonly IConfiguration _configuration;
        public DateTime SessionExpires { get; set; }

        public string[] Genders = new[] {
            AdministrativeGender.Male.ToString(),
            AdministrativeGender.Female.ToString(),
            AdministrativeGender.Other.ToString(),
            AdministrativeGender.Unknown.ToString()
            };
        public string ResResponse { get; set; }
        public string ResSearchCriteria { get; set; }
        public string ResJson { get; set; }
        public List<ResPatient> ResPatients { get; set; }


        [BindProperty(SupportsGet = true)]
        public bool FuzzySearch { get; set; }
        [BindProperty(SupportsGet = true)]
        public string FamilyInput { get; set; }
        [BindProperty(SupportsGet = true)]
        public DateTime BirthdateInput { get; set; }
        [BindProperty(SupportsGet = true)]
        public string GenderInput { get; set; }
        [BindProperty(SupportsGet = true)]
        public string PostcodeInput { get; set; }




        public BasicSearchPostcodeModel(IConfiguration configuration)
        {
            _configuration = configuration;
           
            ResPatients = new List<ResPatient>();
        }


        public IActionResult OnGet()
        {
            BasicRequest requestinput = new BasicRequest();
            requestinput.family = FamilyInput;
            if (GenderInput != null) requestinput.gender = GenderInput.ToLower();
            requestinput.postcode = PostcodeInput;
            requestinput.fuzzysearch = FuzzySearch;
            if (BirthdateInput.Date != DateTime.MinValue.Date) requestinput.birthdate = BirthdateInput.Date.ToString("yyyy-MM-dd"); else requestinput.birthdate = "";

            if (!string.IsNullOrEmpty(FamilyInput))
            {
                ClientRequest request = new ClientRequest(_configuration);
                FhirClient client = request.CreateFHIRClient();
                client = request.SetClientHeaders(client);
                SearchParams conditions = request.SetConditions(requestinput);
                ClientResponse response;
                try
                {
                    response = request.Search(conditions, client);
                  
                }
                catch (Exception e)
                {
                    return RedirectToPage("./Error", new { message = e.Message });
                }
                ResResponse = response.readresponsestatus;
                Bundle results = response.bundle;
                var serializer = new FhirJsonSerializer(new SerializerSettings() { Pretty = true });
                string rawjson = serializer.SerializeToString(results);
                FillFields(results, requestinput, rawjson);
            }
            return Page();
        }



        public void FillFields(Bundle results, BasicRequest request, string rawjson)
        {
            var tokenExpiresAt = _configuration["OAUTH:tokenExpiresAt"];

            PatientResult presult = new PatientResult();
            ResPatients = presult.SetResults(results);
            ResSearchCriteria = $"Family Name: {request.family}, Gender: {request.gender}, Birth Date: {request.birthdate}, Post Code: {request.postcode}, Fuzzy match enabled: {request.fuzzysearch}";
            ResJson = rawjson;
            SessionExpires = Convert.ToDateTime(tokenExpiresAt);
        }
    }
}

