using System.Net.Http;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Hl7.Fhir.Serialization;
using Hl7.Fhir.Model;
using System.Collections.Generic;

namespace PDSFHIRWebapp.Pages
{
    [Authorize]
    public class UpdateContactModel : PageModel
    {
        private readonly IConfiguration _configuration;

        private readonly IResponseData iresponsedata;
        public DateTime SessionExpires { get; set; }

        public Dictionary<string, int> ContactMethods = new Dictionary<string, int>() {
            {"Letter", 1 },
            {"Visit", 2 },
            {"Telephone", 3 },
            {"E-mail", 4 },
            {"Minicom (Textphone)", 5 },
            {"Telephone contact via proxy", 6 },
            {"Sign language", 7 },
            {"No Telephone contact", 8 }
        };

        public Dictionary<string, int> WrittenCommFormats = new Dictionary<string, int>() {
            {"Large print", 11 },
            {"Braille", 12 },
            {"Audio tape", 13 }
        };
        public string ResName { get; set; }
        public string ResPatientID { get; set; }
        public string ResContactMethodFrom { get; set; }
        public string ResContactMethodTo { get; set; }
        public string ResContactTimesFrom { get; set; }
        public string ResContactTimesTo { get; set; }
        public string ResContactWrittenFormatFrom { get; set; }
        public string ResContactWrittenFormatTo { get; set; }
        public string ResJson { get; set; }
        public bool contactMethodExists { get; set; }
        public bool writtenCommsExists { get; set; }
        public bool contactTimesExists { get; set; }
        public string etag { get; set; }
        public string NHSNumber { get; set; }

        [BindProperty(SupportsGet = true)]
        public string ContactMethodInput { get; set; }
        [BindProperty(SupportsGet = true)]
        public string ContactTimeInput { get; set; }
        [BindProperty(SupportsGet = true)]
        public string WrittenCommInput { get; set; }
        public Extension outerExtension { get; set; }
        public int outerExtensionIndex { get; set; }
        int contactMethodIndex = 0, contactTimeIndex = 0, WrittenCommIndex = 0;
        string newcontactprefs = "", oldcontactprefs = "";

        public UpdateContactModel(IConfiguration configuration, IResponseData iresponsedata)
        {
            _configuration = configuration;
            this.iresponsedata = iresponsedata;
            contactTimesExists = false;
            contactMethodExists = false;
            writtenCommsExists = false;
        }
        public async Task<IActionResult> OnGet()
        {
            GlobalSetup();
            if (outerExtension != null)
            {
                InitialLoad(outerExtension);
                if (contactMethodExists) ContactMethodOptions(ResContactMethodFrom);
                if (writtenCommsExists) WrittenCommsFormatOptions(ResContactWrittenFormatFrom);
                JObjectPatch patchbody = patchToReplace();
                if (patchbody.root.patches.Count > 0)
                {
                    ClientResponse response;
                    try
                    {
                        patchbody.root.correction = true;   
                        ClientRequest request = new ClientRequest(_configuration);
                        HttpClient client = request.CreateHTTPClient();
                        client = request.SetClientHeaders(client);
                        response = await request.UpdatePatientAsync(client, patchbody);
                        response.updateValue = IEnums.UpdateValue.Contact;
                        response.contactpreferencesto = newcontactprefs;
                        iresponsedata.SetClientResponseInMemory(response);
                    }
                    catch (Exception e)
                    {
                        return RedirectToPage("./Error", new { message = e.Message });
                    }

                    if (response.resourcetype == ResourceType.OperationOutcome) return RedirectToPage("./OperationOutcome");
                    else
                    {                                   
                        return RedirectToPage("./PollUpdate", new { polling_id = response.pollingid, patchedelement = response.updateValue, patchedvalue = oldcontactprefs });
                    }
                }
                return Page();
            }
            else return RedirectToPage("./AddContactPreference");
        }

        private void GlobalSetup()
        {
            ClientResponse retrievedResponse = iresponsedata.GetClientResponseInMemory();
            etag = retrievedResponse.etag;
            Patient patient = retrievedResponse.patient;
            NHSNumber = patient.Id;
            ResPatientID = patient.Id;
            ResName = patient.Name[0].ToString();
            outerExtension = patient.GetExtension(_configuration["NHSD:ContactPrefURL"]);
            outerExtensionIndex = patient.Extension.IndexOf(outerExtension);            
        }

        public void InitialLoad(Extension outerExtension)
        {
            CodeableConcept contactMethodConcept = outerExtension.GetExtensionValue<CodeableConcept>("PreferredContactMethod");
            CodeableConcept writtenContactConcept = outerExtension.GetExtensionValue<CodeableConcept>("PreferredWrittenCommunicationFormat");
            FhirString preferredContactTimes = outerExtension.GetExtensionValue<FhirString>("PreferredContactTimes");
            if (contactMethodConcept != null)
            {
                ResContactMethodFrom = contactMethodConcept.Coding[0].Display;
                contactMethodExists = true;
            }
            if (writtenContactConcept != null)
            {
                ResContactWrittenFormatFrom = writtenContactConcept.Coding[0].Display;
                writtenCommsExists = true;
            }
            if (preferredContactTimes != null)
            {
                ResContactTimesFrom = preferredContactTimes.ToString();
                contactTimesExists = true;
            }
        }
        private void ContactMethodOptions(string? CurrentContactMethod)
        {
            ContactMethods.Remove(CurrentContactMethod);
        }

        private void WrittenCommsFormatOptions(string? CurrentWrittenFormat)
        {
            WrittenCommFormats.Remove(CurrentWrittenFormat);
        }

        public JObjectPatch patchToReplace()
        {
            JObjectPatch patchbody = new JObjectPatch();
            if (!string.IsNullOrEmpty(ContactMethodInput))
            {
                Extension patchextension = UpdatePreferredContactMethodPatch(outerExtension);
                JObjectPatch.Patch patch = UpdatePatchBody(patchextension, outerExtensionIndex, contactMethodIndex);
                patchbody.root.patches.Add(patch);
                oldcontactprefs += ResContactMethodFrom + ", ";
                newcontactprefs = ContactMethodInput + ", ";
            }
            if (!string.IsNullOrEmpty(WrittenCommInput))
            {
                Extension patchextension = UpdatePreferredWrittenCommunicationFormatPatch(outerExtension);
                JObjectPatch.Patch patch = UpdatePatchBody(patchextension, outerExtensionIndex, WrittenCommIndex);
                patchbody.root.patches.Add(patch);
                oldcontactprefs += ResContactWrittenFormatFrom + ", ";
                newcontactprefs += WrittenCommInput + ", ";
            }
            if (!string.IsNullOrEmpty(ContactTimeInput))
            {
                Extension patchextension = UpdatePreferredContactTimesPatch(outerExtension);
                JObjectPatch.Patch patch = UpdatePatchBody(patchextension, outerExtensionIndex, contactTimeIndex);
                patchbody.root.patches.Add(patch);
                oldcontactprefs += ResContactTimesFrom;
                newcontactprefs += ContactTimeInput;
            }
            patchbody.etag = etag;
            patchbody.NHSNumber = NHSNumber;

            return patchbody;
        }

        public JObjectPatch.Patch UpdatePatchBody(Extension value, int outerExtensionIndex, int innerExtensionIndex)
        {
            JObjectPatch.Patch patch = new JObjectPatch.Patch();

            patch.op = "replace";
            patch.path = $"/extension/{outerExtensionIndex}/extension/{innerExtensionIndex}";
            patch.value = value.ToJObject();
            return patch;
        }

        public Extension UpdatePreferredContactMethodPatch(Extension outerExtension)
        {
            CodeableConcept contactMethodConcept = outerExtension.GetExtensionValue<CodeableConcept>("PreferredContactMethod");
            Extension contactMethodExtension = outerExtension.GetExtension("PreferredContactMethod");
            contactMethodIndex = outerExtension.Extension.IndexOf(contactMethodExtension);
            contactMethodConcept.Coding[0].Display = ContactMethodInput;
            contactMethodConcept.Coding[0].Code = ContactMethods[ContactMethodInput].ToString();
            Extension patchextension = new Extension("PreferredContactMethod", contactMethodConcept);
            return patchextension;
        }
        public Extension UpdatePreferredWrittenCommunicationFormatPatch(Extension outerExtension)
        {
            CodeableConcept writtenContactConcept = outerExtension.GetExtensionValue<CodeableConcept>("PreferredWrittenCommunicationFormat");
            Extension WrittenCommExtension = outerExtension.GetExtension("PreferredWrittenCommunicationFormat");
            WrittenCommIndex = outerExtension.Extension.IndexOf(WrittenCommExtension);
            writtenContactConcept.Coding[0].Display = WrittenCommInput;
            writtenContactConcept.Coding[0].Code = WrittenCommFormats[WrittenCommInput].ToString();
            Extension patchextension = new Extension("PreferredWrittenCommunicationFormat", writtenContactConcept);
            return patchextension;
        }
        public Extension UpdatePreferredContactTimesPatch(Extension outerExtension)
        {
            Extension contactTimeExtension = outerExtension.GetExtension("PreferredContactTimes");
            contactTimeIndex = outerExtension.Extension.IndexOf(contactTimeExtension);
            FhirString value = new FhirString(ContactTimeInput);
            Extension patchextension = new Extension("PreferredContactTimes", value);
            return patchextension;
        }
        
    }
}

