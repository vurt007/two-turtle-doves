using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using System;
using System.Threading.Tasks;

namespace PDSFHIRWebapp.Pages
{

   [Authorize]
    public class LoginModel : PageModel
    {

        private readonly IConfiguration _configuration;
       
        public LoginModel(IConfiguration configuration)
        {
           
            this._configuration = configuration;
        }


        
        public async System.Threading.Tasks.Task OnGet()
        {
            
           await FetchToken();
            

        }



        public async Task<IActionResult> FetchToken()
        {
            
           try
            {
                _configuration["OAUTH:tokenAccess"] = await HttpContext.GetTokenAsync("access_token");
                _configuration["OAUTH:tokenRefresh"] = await HttpContext.GetTokenAsync("refresh_token");
                _configuration["OAUTH:tokenExpiresAt"] = await HttpContext.GetTokenAsync("expires_at");
               
            }
            catch(Exception e)
            {
                return RedirectToPage("./Error", new { message = e.Message });
            }

            return Page();

        }
    }
}

//
