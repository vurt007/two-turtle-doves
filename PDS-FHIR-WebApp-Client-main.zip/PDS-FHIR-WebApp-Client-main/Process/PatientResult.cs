﻿using Hl7.Fhir.Model;
using System.Collections.Generic;
using static PDSFHIRWebapp.ClientResponse;

namespace PDSFHIRWebapp
{
    public class PatientResult
    {

        public List<ResPatient> SetResults(Bundle bundle)
        {
            List<ResPatient> respatients = new List<ResPatient>();

            foreach (var entry in bundle.Entry)
            {
                var patiententry = (Patient)entry.Resource;
                HumanName contact = patiententry.Name[0];

                ResPatient patient = new ResPatient();

                patient.ResName = contact.ToString();
                patient.ResBirthdate = patiententry.BirthDate.ToString();
                patient.ResGender = patiententry.Gender.ToString();
                patient.ResPostcode = patiententry.Address[0].PostalCode;
                patient.ResNHSNumber = patiententry.Id;
                respatients.Add(patient);

            }
            return respatients;

        }

        public ResPatient SetResults(Patient patient)
        {
            ResPatient respatient = new ResPatient();
            respatient.ResName = patient.Name[0].ToString();
            respatient.ResGender = patient.Gender.ToString();
            respatient.ResBirthdate = patient.BirthDate.ToString();
            respatient.ResNHSNumber = patient.Id.ToString();
            return respatient;
        }
    }
}
