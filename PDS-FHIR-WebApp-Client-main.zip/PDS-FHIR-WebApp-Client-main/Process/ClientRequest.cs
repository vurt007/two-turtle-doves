﻿using Fare;
using Hl7.Fhir.Model;
using Hl7.Fhir.Rest;
using Hl7.Fhir.Serialization;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace PDSFHIRWebapp
{
    public class ClientRequest
    {
        public string resultStatus;
        private readonly IConfiguration _configuration;
        private string etag;
        private string statuscode;

        public ClientRequest(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public HttpClient CreateHTTPClient()
        {
            HttpClient client = new HttpClient();
            return client;
        }

        public FhirClient CreateFHIRClient()
        {
            FhirClient client = new FhirClient(_configuration["NHSD:APIEndpoint"]);
            return client;
        }

        public FhirClient SetClientHeaders(FhirClient client)
        {
            client.OnBeforeRequest += (object sender, BeforeRequestEventArgs e) =>
            {
                e.RawRequest.Headers.Add("Authorization", $"Bearer {_configuration["OAUTH:tokenAccess"]}");
                e.RawRequest.Headers.Add("NHSD-Session-URID", _configuration["NHSD:NHSD-Session-URID"]);
                e.RawRequest.Headers.Add("X-Request-ID", GenerateGUID("X-Request-ID"));
                e.RawRequest.Headers.Add("X-Correlation-ID", GenerateGUID("X-Correlation-ID"));
            };

            client.OnAfterResponse += (object sender, AfterResponseEventArgs e) =>
            {
                statuscode = (int)e.RawResponse.StatusCode + ", " + e.RawResponse.StatusCode.ToString();
                etag = e.RawResponse.GetResponseHeader("Etag");
            };
            return client;
        }

        public HttpClient SetClientHeaders(HttpClient client)
        {
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _configuration["OAUTH:tokenAccess"]);
            client.DefaultRequestHeaders.Add("NHSD-Session-URID", _configuration["NHSD:NHSD-Session-URID"]);
            client.DefaultRequestHeaders.Add("accept", "application/json-patch+json");
            client.DefaultRequestHeaders.Add("X-Correlation-ID", GenerateGUID("X-Correlation-ID"));
            client.DefaultRequestHeaders.Add("X-Request-ID", GenerateGUID("X-Request-ID"));
            return client;
        }

        public SearchParams SetConditions(BasicRequest request)
        {
            SearchParams conditions = new SearchParams();
            if (!string.IsNullOrEmpty(request.family)) conditions.Add("family", request.family);
            if (!string.IsNullOrEmpty(request.gender)) conditions.Add("gender", request.gender);
            if (!string.IsNullOrEmpty(request.birthdate)) conditions.Add("birthdate", request.birthdate);
            if (!string.IsNullOrEmpty(request.postcode)) conditions.Add("address-postcode", request.postcode);
            if (request.fuzzysearch) conditions.Add("_fuzzy-match", "true");
            return conditions;
        }
        public ClientResponse Search(SearchParams conditions, FhirClient client)
        {
            ClientResponse response = new ClientResponse();
            var results = new Bundle();
            results.Type = Bundle.BundleType.Searchset;
            try
            {
                response.bundle = client.Search<Patient>(conditions);
            }
            catch
            {

                throw;

            }
            response.readresponsestatus = statuscode;
            response.etag = etag;
            return response;
        }

        public ClientResponse FindNHSNumber(string NHSNumber, FhirClient client)
        {

            try
            {

                ClientResponse patientrecord = new ClientResponse
                {
                    patient = (Patient)client.Get(_configuration["NHSD:APIEndpoint"] + $"/Patient/{NHSNumber}"),
                    etag = etag,
                    resourcetype = ResourceType.Patient,
                    readresponsestatus = statuscode
                };
                return patientrecord;
            }
            catch
            {
                throw;
            }

        }

        public async Task<ClientResponse> UpdatePatientAsync(HttpClient client, StringPatch patchbody)
        {
            etag = patchbody.etag;
            if (!string.IsNullOrEmpty(etag)) client.DefaultRequestHeaders.Add("If-Match", etag);
            ClientResponse patchresponse = new ClientResponse();
            var url = HttpUtility.UrlDecode(_configuration["NHSD:APIEndpoint"] + $"/Patient/{patchbody.NHSNumber}");
            var request = new HttpRequestMessage(HttpMethod.Patch, url);    //Creating the type of request to the URL
            string patchbodystring = JsonConvert.SerializeObject(patchbody.root);
            var data = new StringContent(patchbodystring, Encoding.UTF8, "application/json-patch+json");   //Set the patch request to correct encoding for patch.
            request.Content = data;

            HttpResponseMessage response;
            try
            {
                response = await client.SendAsync(request);   //Make the patch request.
                _configuration["NHSD:statuscode"] = ((int)response.StatusCode).ToString() + ", " + response.StatusCode.ToString();
                // response.EnsureSuccessStatusCode();




            }
            catch (Exception e)
            {
                throw new Exception($"Patching has gone wrong: {e.Message}");
            }
            
            return ProcessResultRequest(response);

        }

        public async Task<ClientResponse> UpdatePatientAsync(HttpClient client, JObjectPatch patchbody)
        {
            etag = patchbody.etag;
            if (!string.IsNullOrEmpty(etag)) client.DefaultRequestHeaders.Add("If-Match", etag);
            ClientResponse patchresponse = new ClientResponse();
            var url = HttpUtility.UrlDecode(_configuration["NHSD:APIEndpoint"] + $"/Patient/{patchbody.NHSNumber}");
            var request = new HttpRequestMessage(HttpMethod.Patch, url);    //Creating the type of request to the URL
            string patchbodystring = JsonConvert.SerializeObject(patchbody.root);
            var data = new StringContent(patchbodystring, Encoding.UTF8, "application/json-patch+json");   //Set the patch request to correct encoding for patch.
            request.Content = data;

            HttpResponseMessage response;
            try
            {
                response = await client.SendAsync(request);   //Make the patch request.
                _configuration["NHSD:statuscode"] = ((int)response.StatusCode).ToString() + ", " + response.StatusCode.ToString();

            }
            catch (Exception e)
            {
                throw new Exception($"Patching has gone wrong: {e.Message}");
            }

            
            return ProcessResultRequest(response);

        }

        private ClientResponse ProcessResultRequest(HttpResponseMessage response)
        {
            ClientResponse clientresponse = new ClientResponse();
            if ((int)response.StatusCode != 202)
            {
       
                string result = response.Content.ReadAsStringAsync().Result;
                clientresponse.RawJson = result;
                FhirJsonParser parser = new FhirJsonParser();
                var jobject = JObject.Parse(result);

                ResourceType resourcetype = (ResourceType)Enum.Parse(typeof(ResourceType), jobject["resourceType"].ToString(), true);
                clientresponse.resourcetype = resourcetype;

                switch (resourcetype)
                {
                    case ResourceType.Patient:
                        clientresponse.patient = parser.Parse<Patient>(result);
                        
                        break;
                    case ResourceType.OperationOutcome:
                        clientresponse.operationoutcome = parser.Parse<OperationOutcome>(result);
                        
                        break;
                    case ResourceType.Bundle:
                        clientresponse.bundle = parser.Parse<Bundle>(result);

                        break;
                    default:
                        throw new Exception("Cannot parse result");    

                }

            } else
            {
                clientresponse.pollingid = response.Content.Headers.ContentLocation.ToString();
                clientresponse.retryafter = response.Headers.RetryAfter.ToString();
                clientresponse.patchresponsestatus = ((int)response.StatusCode).ToString() + ", " + response.StatusCode.ToString();
            }

            
            return clientresponse;
        }


        public async Task<ClientResponse> pollPatient(string pollingid, string retryafter, HttpClient client)
        {
            if (String.IsNullOrEmpty(pollingid)) throw new Exception("Polling ID is empty");

            //if (!string.IsNullOrEmpty(etag)) client.DefaultRequestHeaders.Add("If-Match", etag);
            ClientResponse pollresponse = new ClientResponse();
            int count = 0;
            HttpResponseMessage polledresponse = new HttpResponseMessage();
            try
            {
                do
                {
                    System.Threading.Thread.Sleep(int.Parse(retryafter) * 10);
                    polledresponse = await client.GetAsync($"https://int.api.service.nhs.uk/personal-demographics{pollingid}");
                    _configuration["NHSD:statuscode"] = ((int)polledresponse.StatusCode).ToString() + ", " + polledresponse.StatusCode.ToString();
                    // polledresponse.EnsureSuccessStatusCode();


                    count++;
                } while (count < 10 && (int)polledresponse.StatusCode == 202);

            }
            catch (Exception e)
            {
                throw new Exception($"Pollling has gone wrong, polling id: {pollingid}: count {count}: {e.Message}");
            }

           
             return ProcessResultRequest(polledresponse);
        }
        private string GenerateGUID(string guid)
        {
            string pattern = "[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}";
            var fare = new Xeger(pattern);
            string code = fare.Generate();
            _configuration[$"NHSD:{guid}"] = code;
            return code;
        }
    }
}
